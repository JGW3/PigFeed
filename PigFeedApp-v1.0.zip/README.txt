PIG FEED MANAGEMENT APP
========================

INSTALLATION:
1. Unzip this folder to any location on your computer
2. Double-click PigFeedApp.exe to run the application

REQUIREMENTS:
- Windows 10 or newer
- Java will be automatically detected or you'll be prompted to install it

FEATURES:
- Feed mix calculator with pre-loaded common ingredients:
  * Corn, Milo, Alfalfa Pellets, Soybean Meal
  * Wheat, Barley, Oats
- Cost tracking and spending reports
- Save and load custom feed mixes
- Export reports to Excel and PDF

UNINSTALLING:
- Simply delete this entire folder
- No registry entries or system files are created

SUPPORT:
For questions or issues, visit: [Your GitHub page]

The app comes pre-loaded with common pig feed ingredients and typical pricing. You can modify these as needed for your operation.